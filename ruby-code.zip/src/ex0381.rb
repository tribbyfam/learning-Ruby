# Sample code from Programing Ruby, page 186
  xmp code_string, abinding
  XMP.new(abinding)

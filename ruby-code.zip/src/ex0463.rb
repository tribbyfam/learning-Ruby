# Sample code from Programing Ruby, page 247
  canvas.bind("Motion", lambda {|x, y| do_motion (x, y)}, "%x %y")

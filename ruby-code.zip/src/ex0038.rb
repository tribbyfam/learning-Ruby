# Sample code from Programing Ruby, page 19
verbose_greet("Dave", "loyal customer")  { puts "Hi" }

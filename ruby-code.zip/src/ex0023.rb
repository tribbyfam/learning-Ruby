# Sample code from Programing Ruby, page 16
 count = 99
  if count > 10
    puts "Try again"
  elsif tries == 3
    puts "You lose"
  else
    puts "Enter a number"
  end

# Sample code from Programing Ruby, page 209
require_gem 'BlueCloth', '>= 0.0.4'

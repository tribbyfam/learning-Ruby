# Sample code from Programing Ruby, page 6
  #!/usr/local/bin/ruby -w

  puts "Hello, world!"

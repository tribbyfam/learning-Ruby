# Sample code from Programing Ruby, page 0
  3.times { puts "Hello!" }

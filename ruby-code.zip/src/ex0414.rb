# Sample code from Programing Ruby, page 210
require 'bluecloth'

# Sample code from Programing Ruby, page 210
require 'rubygems'
$".delete('bluecloth.rb')
require_gem 'BlueCloth'

# Sample code from Programing Ruby, page 92
  artist = "John Coltrane"
  use_nicknames = "yes"
  if artist == "John Coltrane"
    artist = "'Trane"
  end unless use_nicknames == "no"

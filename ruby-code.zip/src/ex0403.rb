# Sample code from Programing Ruby, page 200
ruby -r rbconfig -e 'p Config::CONFIG["datadir"]'

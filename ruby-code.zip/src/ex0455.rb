# Sample code from Programing Ruby, page 242
require 'tk'
TkLabel.new { text 'Hello, World!'; pack }
Tk.mainloop

# Sample code from Programing Ruby, page 258
C:\> ruby olegen.rb 'NetMeeting 1.1 Type Library' >netmeeting.rb

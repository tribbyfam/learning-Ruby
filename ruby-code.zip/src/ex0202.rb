# Sample code from Programing Ruby, page 84
  instrument = "piano"
  MIDDLE_A   = 440

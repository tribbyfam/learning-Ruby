# Sample code from Programing Ruby, page 78
    def list_bones(p)
    end
  list_bones("aardvark") do |bone|
    # ...
  end

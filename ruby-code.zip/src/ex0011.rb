# Sample code from Programing Ruby, page 12
  Good night, John-Boy
  Good night, Mary-Ellen

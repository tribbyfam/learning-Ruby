# Sample code from Programing Ruby, page 20
  animals = %w( ant bee cat dog elk )    # create an array
  animals.each {|animal| puts animal }   # iterate over the contents

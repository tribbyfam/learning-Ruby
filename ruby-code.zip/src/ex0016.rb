# Sample code from Programing Ruby, page 13
$greeting = "Hello"        # $greeting is a global variable
@name     = "Prudence"     # @name is an instance variable
puts "#$greeting, #@name"

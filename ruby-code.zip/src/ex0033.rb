# Sample code from Programing Ruby, page 18
 line = "abc"
  if line =~ /Perl|Python/
    puts "Scripting language mentioned: #{line}"
  end

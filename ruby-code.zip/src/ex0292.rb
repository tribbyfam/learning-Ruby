# Sample code from Programing Ruby, page 117
a = 1
def b
  2
end

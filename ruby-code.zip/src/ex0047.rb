# Sample code from Programing Ruby, page 22
  print ARGF.grep(/Ruby/)

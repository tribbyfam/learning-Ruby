# Sample code from Programing Ruby, page 231
    AddType application/x-httpd-eruby .rhtml
    Action application/x-httpd-eruby /cgi-bin/eruby

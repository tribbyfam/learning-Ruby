# Sample code from Programing Ruby, page 256
  Song(artist, title, length):    rem Visual Basic

# Sample code from Programing Ruby, page 13
  def say_goodnight(name)
    result = "Good night, #{name}"
    return result
  end
  puts say_goodnight('Pa')

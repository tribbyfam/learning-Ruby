# Sample code from Programing Ruby, page 94
play_list = ""
def play_list.duration() 100 end
until play_list.duration > 60
  play_list.add(song_list.pop)
end

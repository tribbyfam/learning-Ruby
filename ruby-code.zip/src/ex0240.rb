# Sample code from Programing Ruby, page 95
  print "Hello\n" while false
  begin
    print "Goodbye\n"
  end while false

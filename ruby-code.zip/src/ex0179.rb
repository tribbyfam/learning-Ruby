# Sample code from Programing Ruby, page 76
  self.class
  self.frozen?
  frozen?
  self.id
  id

# Sample code from Programing Ruby, page 124
  str1 = "\001\002\003"
  str2 = ""  #!sh!
  str2 << 1 << 2 << 3
  [ 1, 2, 3 ].pack("c*")

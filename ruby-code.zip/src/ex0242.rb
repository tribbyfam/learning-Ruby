# Sample code from Programing Ruby, page 96
  0.upto(9) do |x|
    print x, " "
  end
    puts

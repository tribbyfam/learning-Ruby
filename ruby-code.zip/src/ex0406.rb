# Sample code from Programing Ruby, page 200
% cd <ruby source base>/lib
% rdoc --ri-system

# Sample code from Programing Ruby, page 81
  a = b = c = 0
  [ 3, 1, 7, 0 ].sort.reverse

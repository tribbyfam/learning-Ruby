# Sample code from Programing Ruby, page 37
  person = "Tim"
  person.id
  person.class
  person

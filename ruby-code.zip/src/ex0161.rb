# Sample code from Programing Ruby, page 71
  "fred:smith".sub(/(\w+):(\w+)/, '\2, \1')
  "nercpyitno".gsub(/(.)(.)/, '\2\1')

# Sample code from Programing Ruby, page 119
  print "Enter your name: "
  name = gets

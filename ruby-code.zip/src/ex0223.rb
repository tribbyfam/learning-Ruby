# Sample code from Programing Ruby, page 91
song = ""
def song.duration() 1 end
unless song.duration > 180 
  cost = 0.25
else
  cost = 0.35
end

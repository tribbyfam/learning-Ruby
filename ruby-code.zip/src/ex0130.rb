# Sample code from Programing Ruby, page 62
  1..10
  'a'..'z'
  my_array = [ 1, 2, 3 ]
  0...my_array.length

# Sample code from Programing Ruby, page 38
  person1 = "Tim"
  person2 = person1

  person1[0] = 'J'
  
  person1
  person2

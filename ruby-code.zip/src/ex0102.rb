# Sample code from Programing Ruby, page 50
  [1,3,5,7].inject {|sum, element| sum+element}
  [1,3,5,7].inject {|product, element| product*element}

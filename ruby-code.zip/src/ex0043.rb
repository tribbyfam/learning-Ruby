# Sample code from Programing Ruby, page 21
  printf("Number: %5.2f,\nString: %s\n", 1.23, "hello")

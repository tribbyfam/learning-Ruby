# Sample code from Programing Ruby, page 251
  Perl/Tk:  $widget = $parent->Widget( [ option => value ] )
  Ruby:     widget = TkWidget.new(parent, option-hash)
            widget = TkWidget.new(parent) { code block }

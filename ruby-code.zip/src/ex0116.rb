# Sample code from Programing Ruby, page 57
    class String
      def inspect
        to_s
      end
    end
  'escape using "\\"'
  'That\'s right'

# Sample code from Programing Ruby, page 49
  [ 1, 3, 5, 7, 9 ].each {|i| puts i }
puts

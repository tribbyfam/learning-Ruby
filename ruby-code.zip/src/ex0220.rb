# Sample code from Programing Ruby, page 91
song = ""
def song.artist() nil end
if song.artist == "Gillespie" then  handle = "Dizzy"
elsif song.artist == "Parker" then  handle = "Bird"
else  handle = "unknown"
end

# Sample code from Programing Ruby, page 256
  excelchart.rotation = 45
  r = excelchart.rotation

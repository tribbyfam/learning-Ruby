# Sample code from Programing Ruby, page 261
  class MyTest
    def initialize
      @arr = Array.new
    end
    def add(obj)
      @arr.push(obj)
    end
  end

# Sample code from Programing Ruby, page 50
  [1,3,5,7].inject(0) {|sum, element| sum+element}
  [1,3,5,7].inject(1) {|product, element| product*element}

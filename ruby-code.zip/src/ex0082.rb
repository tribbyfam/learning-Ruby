# Sample code from Programing Ruby, page 41
  a = [ 3.14159, "pie", 99 ]
  a.class
  a.length
  a[0]
  a[1]
  a[2]
  a[3]

  b = Array.new
  b.class
  b.length
  b[0] = "second"
  b[1] = "array"
  b

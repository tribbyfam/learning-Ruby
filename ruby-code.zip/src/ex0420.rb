# Sample code from Programing Ruby, page 218
package_directory/gemname-gemversion.gem

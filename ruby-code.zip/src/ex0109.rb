# Sample code from Programing Ruby, page 55
  num = 81
  6.times do
    puts "#{num.class}: #{num}"
    num *= num
  end

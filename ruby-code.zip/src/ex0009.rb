# Sample code from Programing Ruby, page 11
 number = -1234
  number = number.abs

# Sample code from Programing Ruby, page 107
  raise ArgumentError, "Name too big", caller[1..-1]

# Sample code from Programing Ruby, page 85
  a, b = 1, 2
  a, b = b, a

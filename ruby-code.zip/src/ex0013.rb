# Sample code from Programing Ruby, page 12
  puts "And good night,\nGrandma"

# Sample code from Programing Ruby, page 117
load 'filename.rb'

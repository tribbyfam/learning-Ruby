# Sample code from Programing Ruby, page 184
  IRB.conf[:PROMPT_MODE] = :MY_PROMPT

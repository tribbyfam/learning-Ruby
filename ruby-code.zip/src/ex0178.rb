# Sample code from Programing Ruby, page 76
  File.size("testfile")
  Math.sin(Math::PI/4)

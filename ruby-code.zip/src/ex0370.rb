# Sample code from Programing Ruby, page 177
% irb -r irb/completion

# Sample code from Programing Ruby, page 16
while line = gets
  puts line.downcase
end

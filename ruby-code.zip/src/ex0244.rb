# Sample code from Programing Ruby, page 96
  [ 1, 1, 2, 3, 5 ].each {|val| print val, " " }
    puts

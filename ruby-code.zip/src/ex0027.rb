# Sample code from Programing Ruby, page 17
 radiation = 1
  puts "Danger, Will Robinson" if radiation > 3000

# Sample code from Programing Ruby, page 91
debug = false; total = 0; date = ''
  mon, day, year = $1, $2, $3 if date =~ /(\d\d)-(\d\d)-(\d\d)/
  puts "a = #{a}" if debug
  print total unless total.zero?

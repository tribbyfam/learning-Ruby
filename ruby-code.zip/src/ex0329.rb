# Sample code from Programing Ruby, page 140
  system("tar xzf test.tgz")
  result = `date`
  result

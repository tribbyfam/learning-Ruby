# Sample code from Programing Ruby, page 100
  [ 1, 2, 3 ].each do |x|
    y = x + 1
  end
  [ x, y ]

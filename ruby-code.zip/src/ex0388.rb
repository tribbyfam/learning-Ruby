# Sample code from Programing Ruby, page 193
#  = Level One Heading
#  == Level Two Heading
#  and so on...

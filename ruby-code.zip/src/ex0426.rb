# Sample code from Programing Ruby, page 223
  require 'cgi'
  puts CGI.escapeElement('<hr><a href="/mp3">Click Here</a><br>','A')

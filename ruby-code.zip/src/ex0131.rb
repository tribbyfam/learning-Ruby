# Sample code from Programing Ruby, page 63
  (1..10).to_a
  ('bar'..'bat').to_a

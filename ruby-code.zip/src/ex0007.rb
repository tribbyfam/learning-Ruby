# Sample code from Programing Ruby, page 10
  song = 1
  sam = ""
  def sam.play(a)
    "duh dum, da dum de dum ..."
  end
  "gin joint".length
  "Rick".index("c")
  -1942.abs
  sam.play(song)

# Sample code from Programing Ruby, page 21
  line = gets
  print line

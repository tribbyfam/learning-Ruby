# Sample code from Programing Ruby, page 32
  File.delete("doomed.txt")

# Sample code from Programing Ruby, page 123
IO.foreach("testfile") {|line| puts line }

# Sample code from Programing Ruby, page 32
  class Example
  
    def instance_method          # instance method
    end

    def Example.class_method     # class method
    end

  end

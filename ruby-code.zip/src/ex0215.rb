# Sample code from Programing Ruby, page 90
false or  nil
nil   or  false
99    or  false

# Sample code from Programing Ruby, page 223
  require 'cgi'
  puts CGI.escape("Nicholas Payton/Trumpet & Flugel Horn")

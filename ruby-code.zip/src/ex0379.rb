# Sample code from Programing Ruby, page 186
require 'irb/xmp'

xmp <<END
artist = "Doc Severinsen"
artist.upcase
END

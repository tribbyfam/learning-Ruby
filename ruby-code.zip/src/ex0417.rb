# Sample code from Programing Ruby, page 214
s.add_dependency("BlueCloth", ">= 0.0.4")

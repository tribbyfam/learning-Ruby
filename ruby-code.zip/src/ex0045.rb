# Sample code from Programing Ruby, page 22
while gets
  if /Ruby/
    print
  end
end

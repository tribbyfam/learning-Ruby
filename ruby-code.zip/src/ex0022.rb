# Sample code from Programing Ruby, page 16
  histogram = Hash.new(0)
  histogram['key1']
  histogram['key1'] = histogram['key1'] + 1
  histogram['key1']

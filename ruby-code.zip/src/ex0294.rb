# Sample code from Programing Ruby, page 117
   require '/usr/lib/ruby/1.9/English.rb'
   require '/usr/lib/ruby/1.9/rdoc/../English.rb'

   $"

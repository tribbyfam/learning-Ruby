# Sample code from Programing Ruby, page 171
ENV['SHELL']
ENV['HOME']
ENV['USER']
ENV.keys.size
ENV.keys[0, 7]

# Sample code from Programing Ruby, page 193
def fred      # :yields: index, position
  ...
  yield line, address

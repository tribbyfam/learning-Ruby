# Sample code from Programing Ruby, page 58
  print <<-STRING1, <<-STRING2
     Concat
     STRING1
        enate
        STRING2
 puts

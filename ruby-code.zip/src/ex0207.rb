# Sample code from Programing Ruby, page 85
int a = 1;
int b = 2;
int temp;

temp = a;
a = b;
b = temp;

# Sample code from Programing Ruby, page 120
  file = File.new("testfile", "r")
  # ... process the file
  file.close

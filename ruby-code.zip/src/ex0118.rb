# Sample code from Programing Ruby, page 58
  puts  "now is #{ def the(a)
                      'the ' + a
                    end
                    the('time')
                  } for all good coders..."

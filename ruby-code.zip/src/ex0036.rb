# Sample code from Programing Ruby, page 19
  { puts "Hello" }       # this is a block

  do                     ###
    club.enroll(person)    # and so is this
    person.socialize       #
  end                    ###

# Sample code from Programing Ruby, page 90
song = ""
def song.artist() nil end
if song.artist == "Gillespie"
  handle = "Dizzy"
elsif song.artist == "Parker"
  handle = "Bird"
else
  handle = "unknown"
end

# Sample code from Programing Ruby, page 99
Now at 1. Restart? n
Now at 2. Restart? y
Now at 1. Restart? n
 . . .

# Sample code from Programing Ruby, page 134
  @count += 1

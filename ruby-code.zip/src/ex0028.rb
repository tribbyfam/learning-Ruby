# Sample code from Programing Ruby, page 17
  square = 2
  while square < 1000
     square = square*square
  end

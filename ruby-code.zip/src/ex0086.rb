# Sample code from Programing Ruby, page 43
  h = { 'dog' => 'canine', 'cat' => 'feline', 'donkey' => 'asinine' }

  h.length
  h['dog']
  h['cow'] = 'bovine'
  h[12]    = 'dodecine'
  h['cat'] = 99
  h

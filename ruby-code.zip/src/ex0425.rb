# Sample code from Programing Ruby, page 223
  require 'cgi'
  puts CGI.escapeHTML("a < 100 && b > 200")

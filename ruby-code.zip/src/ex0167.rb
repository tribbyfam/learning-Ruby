# Sample code from Programing Ruby, page 73
  re = /cat/
  re.class

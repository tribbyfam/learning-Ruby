# Sample code from Programing Ruby, page 193
fred() {|index, position| ... }

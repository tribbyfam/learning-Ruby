# Sample code from Programing Ruby, page 106
raise
raise "bad mp3 encoding"
raise InterfaceException, "Keyboard failure", caller

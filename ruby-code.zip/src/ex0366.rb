# Sample code from Programing Ruby, page 172
  % ruby -e 'puts $:'

# Sample code from Programing Ruby, page 96
  3.times do
    print "Ho! "
  end
    puts

# Sample code from Programing Ruby, page 15
  a = [ 'ant', 'bee', 'cat', 'dog', 'elk' ]
  a[0]
  a[3]
  # this is the same:
  a = %w{ ant bee cat dog elk }
  a[0]
  a[3]

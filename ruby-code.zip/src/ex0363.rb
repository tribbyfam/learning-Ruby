# Sample code from Programing Ruby, page 170
ARGV.each {|arg| p arg }

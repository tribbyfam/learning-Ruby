# Sample code from Programing Ruby, page 232
system("/Users/dave/ruby1.8/bin/erb <code/erb/f2.erb")

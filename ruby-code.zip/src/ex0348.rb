# Sample code from Programing Ruby, page 152
% ruby ../test/test_roman.rb

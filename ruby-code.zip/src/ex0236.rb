# Sample code from Programing Ruby, page 94
  a = 1
  a *= 2  while a < 100  #!sh!
  a -= 10 until a < 100  #!sh!
  a

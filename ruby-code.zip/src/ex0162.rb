# Sample code from Programing Ruby, page 71
 str = ''
str.gsub(/\\/, '\\\\')

# Sample code from Programing Ruby, page 114
  [ 1, 2, 3, 4, 5 ].inject {|v,n| v+n }
  ( 'a'..'m').inject {|v,n| v+n }

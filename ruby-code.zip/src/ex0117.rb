# Sample code from Programing Ruby, page 57
    class String
      def inspect
        to_s
      end
    end
  "Seconds/day: #{24*60*60}"
  "#{'Ho! '*3}Merry Christmas!"
 $. = 3
  "This is line #$."

# Sample code from Programing Ruby, page 128
puts "Fetching: www.rubycentral.com"
puts "Fetching: slashdot.org"
puts "Fetching: www.google.com"
puts "Got www.google.com:  OK"
puts "Got www.rubycentral.com:  OK"
puts "Got slashdot.org:  OK"

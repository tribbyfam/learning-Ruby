# Sample code from Programing Ruby, page 82
  song[0, 15].play

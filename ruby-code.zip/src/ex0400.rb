# Sample code from Programing Ruby, page 197
rb_define_method(cCipher, "md5", gen_md5, -1); /* in md5.c */

# Sample code from Programing Ruby, page 98
  i=0
  loop do
    i += 1
    next if i < 3
    print i
    break if i > 4
  end
    puts

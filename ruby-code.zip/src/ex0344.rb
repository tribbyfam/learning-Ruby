# Sample code from Programing Ruby, page 148
require 'test/unit'

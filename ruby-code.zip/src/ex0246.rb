# Sample code from Programing Ruby, page 97
loop do
  # block ...
end

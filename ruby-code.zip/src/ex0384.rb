# Sample code from Programing Ruby, page 192
#  Lists are typed as indented paragraphs with:
#  * a '*' or '-' (for bullet lists)
#  * a digit followed by a period for 
#    numbered lists
#  * an upper or lower case letter followed
#    by a period for alpha lists.

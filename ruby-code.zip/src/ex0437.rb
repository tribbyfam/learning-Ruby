# Sample code from Programing Ruby, page 230
system("/Users/dave/ruby1.8/bin/erb -x <code/erb/f1.erb")
#erb -x f1.erb

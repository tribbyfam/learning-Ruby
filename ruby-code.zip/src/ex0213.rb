# Sample code from Programing Ruby, page 88
  defined? 1
  defined? dummy
  defined? printf
  defined? String
  defined? $_
  defined? Math::PI
  defined? a = 1
  defined? 42.abs

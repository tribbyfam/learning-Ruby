# Sample code from Programing Ruby, page 18
 line = 'abc'
  line.gsub(/Perl|Python/, 'Ruby')

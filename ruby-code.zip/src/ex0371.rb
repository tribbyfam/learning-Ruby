# Sample code from Programing Ruby, page 177
require 'irb/completion'

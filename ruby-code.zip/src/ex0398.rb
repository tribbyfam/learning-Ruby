# Sample code from Programing Ruby, page 197
/*
 * call-seq:
 *   cipher.keylen   -> Fixnum or nil
 */

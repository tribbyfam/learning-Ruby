# Sample code from Programing Ruby, page 257
  Song title := 'Get It On':      rem Visual Basic

# Sample code from Programing Ruby, page 197
/*
 * Document-method: reset
 *
 * Clear the current buffer and prepare to add new 
 * cipher text. Any accumulated output cipher text
 * is also cleared.
 */

# Sample code from Programing Ruby, page 18
  /P(erl|ython)/

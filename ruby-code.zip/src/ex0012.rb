# Sample code from Programing Ruby, page 12
  puts say_goodnight("John-Boy")
  puts(say_goodnight("John-Boy"))

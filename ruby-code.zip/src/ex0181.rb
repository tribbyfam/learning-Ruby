# Sample code from Programing Ruby, page 77
  def meth_one
    "one"
  end
  meth_one

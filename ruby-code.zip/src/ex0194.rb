# Sample code from Programing Ruby, page 82
  a,b,c=1,2,3
  (a.*(b)).+(c)

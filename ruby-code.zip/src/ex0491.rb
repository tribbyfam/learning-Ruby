# Sample code from Programing Ruby, page 268
#if !defined(StringValue)
#  define StringValue(x) (x)
#endif

#if !defined(StringValuePtr)
#  define StringValuePtr(x) ((STR2CSTR(x)))
#end

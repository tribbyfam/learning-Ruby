# Sample code from Programing Ruby, page 160
c = "carbon"
i = "iodine"
elements = [ c, i ]
elements.each_with_index do |element, i|
  # do some chemistry
end
c
i

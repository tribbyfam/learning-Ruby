# Sample code from Programing Ruby, page 29
  class JavaSong {                     // Java code
    private Duration _duration;
    public void setDuration(Duration newDuration) {
      _duration = newDuration;
    }
  }
  s = new Song(....);
  s.setDuration(length);

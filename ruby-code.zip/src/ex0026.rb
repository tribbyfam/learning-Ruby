# Sample code from Programing Ruby, page 17
 radiation = 1
  if radiation > 3000
    puts "Danger, Will Robinson"
  end

# Sample code from Programing Ruby, page 83
 `date`
 `ls`.split[34]
 %x{echo "Hello there"}

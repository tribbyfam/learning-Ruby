# Sample code from Programing Ruby, page 64
  (1..10)    === 5
  (1..10)    === 15
  (1..10)    === 3.14159
  ('a'..'j') === 'c'
  ('a'..'j') === 'z'

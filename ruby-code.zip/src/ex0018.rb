# Sample code from Programing Ruby, page 14
  a = [ 1, 'cat', 3.14 ]   # array with three elements
  # access the first element
  a[0]
  # set the third element
  a[2] = nil
  # dump out the array
  a

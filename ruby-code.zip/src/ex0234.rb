# Sample code from Programing Ruby, page 94
  while line = gets
    # ...
  end

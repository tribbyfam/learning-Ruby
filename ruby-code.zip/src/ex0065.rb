# Sample code from Programing Ruby, page 32
  song = Song.new(....)

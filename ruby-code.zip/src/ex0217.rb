# Sample code from Programing Ruby, page 90
  (words[key] ||= []) << word

# Sample code from Programing Ruby, page 111
 $: << 'code'
require 'trig'
require 'moral'

y = Trig.sin(Trig::PI/4)
wrongdoing = Moral.sin(Moral::VERY_BAD)

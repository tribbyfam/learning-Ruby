# Sample code from Programing Ruby, page 121
while line = gets
  puts line
end

# Sample code from Programing Ruby, page 195
    rb_define_method(cCipher, "salt=", salt_set, 1);

# Sample code from Programing Ruby, page 252
  Perl/Tk:  -textvariable => \$variable
            -textvariable => varRef
  Ruby:     ref = TkVariable.new
            'textvariable' => ref
            { textvariable ref }

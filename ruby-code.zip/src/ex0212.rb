# Sample code from Programing Ruby, page 88
  while line = gets
    # process line
  end

# Sample code from Programing Ruby, page 10
class Song
def initialize(a)
end
end
  song1 = Song.new("Ruby Tuesday")
  song2 = Song.new("Enveloped in Python")
  # and so on

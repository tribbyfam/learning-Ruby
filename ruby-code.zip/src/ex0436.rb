# Sample code from Programing Ruby, page 230
system("/Users/dave/ruby1.8/bin/erb <code/erb/f1.erb")
#erb f1.erb

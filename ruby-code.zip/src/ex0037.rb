# Sample code from Programing Ruby, page 19
greet  { puts "Hi" }

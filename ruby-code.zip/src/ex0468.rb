# Sample code from Programing Ruby, page 252
  Perl/Tk:  -background => color
  Ruby:     'background' => color
            { background color }

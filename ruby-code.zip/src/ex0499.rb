# Sample code from Programing Ruby, page 273
cd = CDPlayer.new

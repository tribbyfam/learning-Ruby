# Sample code from Programing Ruby, page 258
      workbook.Worksheets(1).Range("A1").value = 1
      workbook.Worksheets(1).Range("A2").value = 2
      workbook.Worksheets(1).Range("A3").value = 4
      workbook.Worksheets(1).Range("A4").value = 8

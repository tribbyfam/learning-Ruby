# Sample code from Programing Ruby, page 124
  endl = "\n"
  STDOUT << 99 << " red balloons" << endl

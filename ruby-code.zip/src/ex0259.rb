# Sample code from Programing Ruby, page 100
if false
  a = 1
end
3.times {|i| a = i }

a

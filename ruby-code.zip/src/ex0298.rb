# Sample code from Programing Ruby, page 120
  File.open("testfile", "r") do |file|
    # ... process the file
  end

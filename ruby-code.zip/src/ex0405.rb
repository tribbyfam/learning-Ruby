# Sample code from Programing Ruby, page 200
% rdoc --ri-site  file1.rb file2.rb

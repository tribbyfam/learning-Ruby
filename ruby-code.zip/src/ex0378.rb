# Sample code from Programing Ruby, page 185
  eval "var = 0" 
  var

# Sample code from Programing Ruby, page 17
  /Perl|Python/

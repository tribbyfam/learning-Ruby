# Sample code from Programing Ruby, page 208
require 'bluecloth'

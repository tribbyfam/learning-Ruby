# Sample code from Programing Ruby, page 199
main*.rb
constants.rb

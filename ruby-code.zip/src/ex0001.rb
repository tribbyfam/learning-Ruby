# Sample code from Programing Ruby, page 0
  class SampleCode
    def run
      #...
    end
  end

# Sample code from Programing Ruby, page 186
require 'irb/xmp'

x = XMP.new
x.puts 'artist = "Louis Prima"'
x.puts 'artist.upcase'

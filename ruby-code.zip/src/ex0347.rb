# Sample code from Programing Ruby, page 152
require 'test/unit'
require '../lib/roman'

class TestRoman < Test::Unit::TestCase
  # ...
end

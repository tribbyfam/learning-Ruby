# Sample code from Programing Ruby, page 272
static void cd_free(void *p) {
  free_jukebox(p);
} 

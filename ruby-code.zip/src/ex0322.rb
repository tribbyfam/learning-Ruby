# Sample code from Programing Ruby, page 134
  val = fetch_current(@count)
  add 1 to val
  store val back into @count

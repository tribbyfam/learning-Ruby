# Sample code from Programing Ruby, page 173
require 'rbconfig.rb'
include Config
CONFIG["host"]
CONFIG["libdir"]

# Sample code from Programing Ruby, page 17
  square = 2
  square = square*square  while square < 1000

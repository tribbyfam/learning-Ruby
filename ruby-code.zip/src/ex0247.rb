# Sample code from Programing Ruby, page 97
songlist = ""
def songlist.each() end
for song in songlist
  song.play
end

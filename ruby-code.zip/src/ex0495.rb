# Sample code from Programing Ruby, page 270
  static VALUE obj;
  // ...
  obj = rb_ary_new();
  rb_global_variable(obj);

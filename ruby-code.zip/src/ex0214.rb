# Sample code from Programing Ruby, page 89
nil   and  true
false and  true
99    and  false
99    and  nil
99    and  "cat"

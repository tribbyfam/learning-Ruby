# Sample code from Programing Ruby, page 257
  Song.new('title' => 'Get It On')

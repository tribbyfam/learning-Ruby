# Sample code from Programing Ruby, page 263
require 'mkmf'
create_makefile("my_test")

# Sample code from Programing Ruby, page 0
  a = 1
  b = 2
  a + b

# Sample code from Programing Ruby, page 85
  x = 0
  a, b, c  =  x, (x += 1), (x += 1)

# Sample code from Programing Ruby, page 193
def fred
  ...
  yield line, address

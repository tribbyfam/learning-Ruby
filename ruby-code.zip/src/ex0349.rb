# Sample code from Programing Ruby, page 152
$:.unshift File.join(File.dirname(__FILE__), "..", "lib")

require ...

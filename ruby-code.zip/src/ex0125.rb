# Sample code from Programing Ruby, page 60
 length = '3:45'
  mins, secs = length.split(/:/)

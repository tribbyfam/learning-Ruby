# Sample code from Programing Ruby, page 52
class Button
  def initialize(label)
  end
end
start_button = Button.new("Start")
pause_button = Button.new("Pause")
# ...

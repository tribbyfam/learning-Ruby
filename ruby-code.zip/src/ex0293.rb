# Sample code from Programing Ruby, page 117
 $: << "code"
a = "cat"
b = "dog"
require 'included'
a
b
b()

# Sample code from Programing Ruby, page 269
    $hardware = [ "DVD", "CDPlayer1", "CDPlayer2" ]
  $hardware

# Sample code from Programing Ruby, page 21
  [ 'cat', 'dog', 'horse' ].each {|name| print name, " " }
  5.times {  print "*" }
  3.upto(6) {|i|  print i }
  ('a'..'e').each {|char| print char }
 puts

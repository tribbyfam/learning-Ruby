# Sample code from Programing Ruby, page 41
  a = [ 1, 3, 5, 7, 9 ]
  a[-1]
  a[-2]
  a[-99]

# Sample code from Programing Ruby, page 91
song = ""
def song.duration() 1 end
cost = song.duration > 180 ? 0.35 : 0.25

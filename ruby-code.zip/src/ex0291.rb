# Sample code from Programing Ruby, page 117
require 'filename'

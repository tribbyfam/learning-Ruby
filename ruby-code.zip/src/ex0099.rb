# Sample code from Programing Ruby, page 49
  ["H", "A", "L"].collect {|x| x.succ }

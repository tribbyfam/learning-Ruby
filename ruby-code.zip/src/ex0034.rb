# Sample code from Programing Ruby, page 18
 line = "abc"
  line.sub(/Perl/, 'Ruby')    # replace first 'Perl' with 'Ruby'
  line.gsub(/Python/, 'Ruby') # replace every 'Python' with 'Ruby'

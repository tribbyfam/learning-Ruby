# Sample code from Programing Ruby, page 105
  Errno::EAGAIN::Errno
  Errno::EPERM::Errno
  Errno::EIO::Errno
  Errno::EWOULDBLOCK::Errno

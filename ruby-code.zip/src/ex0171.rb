# Sample code from Programing Ruby, page 74
  def my_new_method(arg1, arg2, arg3)     # 3 arguments
    # Code for the method would go here
  end

  def my_other_new_method                  # No arguments
    # Code for the method would go here
  end

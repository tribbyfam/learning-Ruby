# Sample code from Programing Ruby, page 13
  def say_goodnight(name)
    "Good night, #{name}"
  end
  puts say_goodnight('Ma')

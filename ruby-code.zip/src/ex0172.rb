# Sample code from Programing Ruby, page 75
  def cool_dude(arg1="Miles", arg2="Coltrane", arg3="Roach")
    "#{arg1}, #{arg2}, #{arg3}."
  end

  cool_dude
  cool_dude("Bart")
  cool_dude("Bart", "Elwood")
  cool_dude("Bart", "Elwood", "Linus")

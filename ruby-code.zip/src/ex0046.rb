# Sample code from Programing Ruby, page 22
  ARGF.each {|line|  print line  if line =~ /Ruby/ }

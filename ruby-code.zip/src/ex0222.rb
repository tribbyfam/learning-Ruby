# Sample code from Programing Ruby, page 91
song = ""
def song.artist() nil end
handle = if song.artist == "Gillespie" then
           "Dizzy"
         elsif song.artist == "Parker" then
           "Bird"
         else
           "unknown"
         end

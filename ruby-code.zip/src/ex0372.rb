# Sample code from Programing Ruby, page 179
IRB.conf[:PROMPT_MODE] = :SIMPLE

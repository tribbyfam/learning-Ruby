# Sample code from Programing Ruby, page 64
  while gets
    print if /start/../end/
  end

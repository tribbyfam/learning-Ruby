# Sample code from Programing Ruby, page 258
      worksheet = workbook.Worksheets(1)

      worksheet.Range("A1").value = 1
      worksheet.Range("A2").value = 2
      worksheet.Range("A3").value = 4
      worksheet.Range("A4").value = 8

# Sample code from Programing Ruby, page 192
#  [cat]    small domestic animal
#  [+cat+]  command to copy standard input
#           to standard output

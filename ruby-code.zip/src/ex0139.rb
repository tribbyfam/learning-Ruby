# Sample code from Programing Ruby, page 65
  name = "Fats Waller"
  name =~ /a/
  name =~ /z/
  /a/ =~ name

# Sample code from Programing Ruby, page 96
  0.step(12, 3) {|x| print x, " " }
    puts

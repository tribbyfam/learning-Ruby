# Sample code from Programing Ruby, page 231
  DirectoryIndex index.html index.shtml index.rhtml

# Sample code from Programing Ruby, page 11
  number = Math.abs(number)     // Java code
